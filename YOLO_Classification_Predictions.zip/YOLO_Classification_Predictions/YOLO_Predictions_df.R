library(dplyr)
library(readr)
library(purrr)

# List all prediction files
pred_files <- list.files("C:\\Users\\fatma\\Documents\\Lodging\\", 
                         pattern = "classification_predictions_fold.*_yolo.*\\.csv$", 
                         full.names = TRUE)

# Read and combine
all_preds <- pred_files %>% 
  map_dfr(~read_csv(.))

all_preds <- all_preds %>%
  mutate(Name = gsub("\\.jpg$|\\.png$", "", image_file))

annotations <- read_csv("C:\\Users\\fatma\\Documents\\Lodging\\human_labeled_datasets\\Combined_Envs\\final.Combined.Envs.Lodging.csv")
# Replace with your actual CSV file/path

library(tidyr)
# Create a long table so predictions from all models/folds can be merged
all_preds_wide <- all_preds %>%
  select(Name, fold, yolo_version, pred_class_name) %>%
  mutate(pred_col = paste0("YOLOv", yolo_version, "_fold", fold, "_pred")) %>%
  select(Name, pred_col, pred_class_name) %>%
  pivot_wider(names_from = pred_col, values_from = pred_class_name)

final_merged <- annotations %>%
  left_join(all_preds_wide, by = "Name")

#######################
library(dplyr)

# Function to calculate mode (most frequent value)
mode_class <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

# For each image, find mode of predicted class
mode_preds <- all_preds %>%
  group_by(Name) %>%
  summarise(mode_pred_class = mode_class(pred_class_name))

# Merge mode values into final_merged
final_merged <- final_merged %>%
  left_join(mode_preds, by = "Name")

head(final_merged[, c("Name", "Lodging", "mode_pred_class")])

df_mode <- final_merged %>%
  select(Name, Lodging, mode_pred_class)

df_mode <- df_mode %>%
  rename(
    Human = Lodging,
    YOLO  = mode_pred_class
  )
#######################
write_csv(final_merged, "C:/Users/fatma/Documents/Lodging/merged_annotations_yolo.csv")
write_csv(df_mode, "C:/Users/fatma/Documents/Lodging/final_merged_annotations_yolo.csv")

