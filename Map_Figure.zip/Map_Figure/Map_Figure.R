library(maps)
library(ggplot2)
locations <- read.csv('C:\\Users\\fatma\\Documents\\Lodging\\Map_Figure\\Map_data.csv', header=T)
head(locations)
dim(locations)

#generate U.S. map with state boundaries
us_map <- map_data("state")

#locations$flight_range <- cut(locations$Flights,
#breaks = c(0, 10, 20, 30, 40, 50),
#labels = c("1-10", "11-20", "21-30", "31-40", "41-50"),
#right = TRUE)
locations$Flights <- as.factor(locations$Flights)


# Create the plot
my_hex_colors <- c("#27AE60", "#98F")

library(ggrepel)

p <- ggplot() +
  geom_polygon(data = us_map, aes(x=long, y=lat, group=group), fill="white", color="gray30") +
  geom_point(
    data = locations,
    aes(x = Longitude, y = Latitude, color = Flights),
    size = 3.5,
    position = position_jitter(width = 0.2, height = 0.2)
  ) +
  geom_text_repel(
    data = locations,
    aes(x = Longitude, y = Latitude, label = Location),
    size = 5,                       # Make the text larger
    fontface = "bold",              # Make it bold
    segment.color = "black",        # Make segments visible
    segment.size = 0.5,             # Make segments thicker
    position = position_jitter(width = 0.5, height = 0.5)
  ) +
  scale_color_manual(values = my_hex_colors, name = "Number of Flights") +
  guides(color = guide_legend(override.aes = list(size = 5))) +
  theme_bw() +
  theme(
    legend.text = element_text(size = 16),
    legend.title = element_text(size = 18),
    legend.key.height = unit(1, 'cm'),
    legend.key.width  = unit(1, 'cm'),
    plot.title = element_text(hjust = 0.5),
    axis.text.x = element_text(size = 12),
    axis.text.y = element_text(size = 12),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.background = element_rect(fill = alpha("gray80", 0.5), size = 0.5, linetype = "solid"),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position  = c(0.9, 0.15)
  ) +
  scale_x_continuous("Longitude") +
  scale_y_continuous("Latitude")

print(p)

ggsave(path = "C:\\Users\\fatma\\Documents\\Lodging\\Map_Figure", width = 9, height = 5, device='tiff', dpi=700, filename= "Map_Figure.tiff")
