# Set directory
dir_path <- "C:/Users/fatma/Documents/Lodging/Correlation_Yield_Plot"

# List all CSV files
csv_files <- list.files(dir_path, pattern = "\\.csv$", full.names = TRUE)

library(dplyr)
library(readr)

# Function to read and select columns
select_columns <- function(file) {
  df <- read_csv(file)
  # Select Pedigree and M* columns
  df_selected <- df %>%
    select(Pedigree, starts_with("M"))
  return(df_selected)
}

# Read and select columns for all files
df_list <- lapply(csv_files, select_columns)

library(purrr)

# Join all data frames by Pedigree
merged_df <- reduce(df_list, left_join, by = "Pedigree")
# Remove the last three columns
merged_df2 <- merged_df[ , -( (ncol(merged_df)-2) : ncol(merged_df) ) ]

df <- merged_df2
head(df)

##############################

library(corrplot)

# Remove Pedigree column for correlation
df_numeric <- df %>% dplyr::select(-Pedigree)

# Compute correlation
cor_matrix <- cor(df_numeric, use = 'pairwise.complete.obs')

# Plot (this matches your example almost exactly)
corrplot(cor_matrix,
         method = "square",
         type = "lower",      # lower triangle only
         addCoef.col = "white", # add correlation value in plot
         tl.col = "navy",     # variable label color
         tl.srt = 45,         # text label angle
         diag = FALSE,        # don't show diagonal
         number.cex = 2,             # <-- Increase this number for bigger labels
         col = colorRampPalette(c("red", "white", "blue"))(200),
         cl.lim = c(-1, 1),   # color limits
         tl.cex = 1.2)        # variable label size

png("C:/Users/fatma/Documents/Lodging/Correlation_Yield_Plot/corrplot_heatmap.png", width = 900, height = 900, res = 150)
corrplot(cor_matrix, method = "square", type = "lower", ...)
dev.off()