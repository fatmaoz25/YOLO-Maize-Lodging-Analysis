#######################################
#######################################
######### MOH2.2021 ###################
#######################################
#######################################


############################
####### Images #############
############################

library(tidyr)
library(dplyr)
library(ggplot2)

df <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\images_and_labels_for_YOLO_training\\MOH2.2021\\splits_with_annotations.csv")

df_long <- df %>%
  pivot_longer(cols = starts_with("fold"),
               names_to = "fold",
               values_to = "split")

# Calculate group counts
counts_df <- df_long %>%
  group_by(fold, split) %>%
  summarise(count = n(), .groups = 'drop')

ggplot(counts_df, aes(x = fold, y = count, fill = split)) +
  geom_bar(stat = "identity", position = position_dodge(width=0.9)) +
  geom_text(aes(label = count), 
            position = position_dodge(width=0.9), 
            vjust = -0.25, size = 3) +
  labs(title = "MOH2.2021 Image Counts within Folds", y="Count", x="Fold") +
  theme_minimal()


ggplot(counts_df, aes(x = fold, y = count, fill = split)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = count), 
            position = position_stack(vjust = 0.5), 
            size = 5, color = "black") +
  labs(title = "MOH2.2021Image Counts within Folds", y="Count", x="Fold") +
  theme_minimal()

ggsave(path = "C:\\Users\\fatma\\Documents\\Lodging\\Counts_Figures", width = 9, height = 5, device='tiff', dpi=700, filename= "MOH2.2021_Images_Counts_Figure.tiff")

length(unique(df$Name))

############################
######### Plots ############
############################

library(dplyr)
library(tidyr)
library(ggplot2)

# If not already done, pivot to long:
df_long <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split"
  ) %>%
  # Only keep train/val/test (if you have extra 'trainval' etc)
  filter(split %in% c("train", "val", "test"))

df_plot <- df_long %>%
  distinct(Plot_ID, fold, split)

df_plot <- df_plot %>%
  group_by(fold) %>%
  arrange(split, Plot_ID, .by_group = TRUE) %>%
  mutate(idx = row_number()) %>%
  ungroup()

counts_df <- df_plot %>%
  group_by(fold, split) %>%
  summarise(count = n(), .groups = 'drop')

ggplot(counts_df, aes(x = fold, y = count, fill = split)) +
  geom_bar(stat = "identity", position = "stack") +
  geom_text(aes(label = count), 
            position = position_stack(vjust = 0.5), 
            color = "white", size = 4) +
  labs(title = "MOH2.2021 Unique Plots per Fold",
       x = "Fold", y = "Number of Unique Plots") +
  scale_fill_manual(values = c(train = "#1b9e77", val = "#d95f02", test = "#7570b3")) +
  theme_minimal()+
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )


ggsave(path = "C:\\Users\\fatma\\Documents\\Lodging\\Counts_Figures", width = 9, height = 5, device='tiff', dpi=700, filename= "MOH2.2021_Plots_Counts_Figure.tiff")

length(unique(df$Plot_ID))

############################
####### Genotype ###########
############################

# If not already done, pivot to long:
df_long <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split"
  ) %>%
  # Only keep train/val/test (if you have extra 'trainval' etc)
  filter(split %in% c("train", "val", "test"))

df_plot <- df_long %>%
  distinct(Pedigree, fold, split)

df_plot <- df_plot %>%
  group_by(fold) %>%
  arrange(split, Pedigree, .by_group = TRUE) %>%
  mutate(idx = row_number()) %>%
  ungroup()

counts_df <- df_plot %>%
  group_by(fold, split) %>%
  summarise(count = n(), .groups = 'drop')

counts_df <- counts_df %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

ggplot(counts_df, aes(x = fold_number, y = count, fill = split)) +
  geom_bar(stat = "identity", position = "stack") +
  geom_text(aes(label = count), 
            position = position_stack(vjust = 0.5), 
            color = "white", size = 10) +
  labs(title = "MOH2.2021 Unique Genotypes per Fold",
       x = "Fold", y = "Number of Unique Genotypes") +
  scale_fill_manual(values = c(train = "#1b9e77", val = "#d95f02", test = "#7570b3")) +
  theme_minimal()+
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )


ggsave(path = "C:\\Users\\fatma\\Documents\\Lodging\\Counts_Figures", width = 9, height = 5, device='tiff', dpi=700, filename= "MOH2.2021_Genotypes_Counts_Figure.tiff")

length(unique(df$Pedigree))

#######################################
#######################################
######### DEH1.2020 ###################
#######################################
#######################################


############################
####### Images #############
############################

library(tidyr)
library(dplyr)
library(ggplot2)

df <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\images_and_labels_for_YOLO_training\\DEH1.2020\\splits_with_annotations.csv")

df_long <- df %>%
  pivot_longer(cols = starts_with("fold"),
               names_to = "fold",
               values_to = "split")

# Calculate group counts
counts_df <- df_long %>%
  group_by(fold, split) %>%
  summarise(count = n(), .groups = 'drop')

ggplot(counts_df, aes(x = fold, y = count, fill = split)) +
  geom_bar(stat = "identity", position = position_dodge(width=0.9)) +
  geom_text(aes(label = count), 
            position = position_dodge(width=0.9), 
            vjust = -0.25, size = 3) +
  labs(title = "DEH1.2020 Image Counts within Folds", y="Count", x="Fold") +
  theme_minimal()


ggplot(counts_df, aes(x = fold, y = count, fill = split)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = count), 
            position = position_stack(vjust = 0.5), 
            size = 5, color = "black") +
  labs(title = "DEH1.2020 Image Counts within Folds", y="Count", x="Fold") +
  theme_minimal()

ggsave(path = "C:\\Users\\fatma\\Documents\\Lodging\\Counts_Figures", width = 9, height = 5, device='tiff', dpi=700, filename= "DEH1.2020_Image_Counts_Figure.tiff")

length(unique(df$Name))

############################
######### Plots ############
############################

library(dplyr)
library(tidyr)
library(ggplot2)

# If not already done, pivot to long:
df_long <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split"
  ) %>%
  # Only keep train/val/test (if you have extra 'trainval' etc)
  filter(split %in% c("train", "val", "test"))

df_plot <- df_long %>%
  distinct(Plot_ID, fold, split)

df_plot <- df_plot %>%
  group_by(fold) %>%
  arrange(split, Plot_ID, .by_group = TRUE) %>%
  mutate(idx = row_number()) %>%
  ungroup()

counts_df <- df_plot %>%
  group_by(fold, split) %>%
  summarise(count = n(), .groups = 'drop')

ggplot(counts_df, aes(x = fold, y = count, fill = split)) +
  geom_bar(stat = "identity", position = "stack") +
  geom_text(aes(label = count), 
            position = position_stack(vjust = 0.5), 
            color = "white", size = 4) +
  labs(title = "DEH1.2020 Unique Plots per Fold",
       x = "Fold", y = "Number of Unique Plots") +
  scale_fill_manual(values = c(train = "#1b9e77", val = "#d95f02", test = "#7570b3")) +
  theme_minimal()+
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )


ggsave(path = "C:\\Users\\fatma\\Documents\\Lodging\\Counts_Figures", width = 9, height = 5, device='tiff', dpi=700, filename= "DEH1.2020_Plots_Counts_Figure.tiff")

length(unique(df$Plot_ID))

############################
####### Genotype ###########
############################

# If not already done, pivot to long:
df_long <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split"
  ) %>%
  # Only keep train/val/test (if you have extra 'trainval' etc)
  filter(split %in% c("train", "val", "test"))

df_plot <- df_long %>%
  distinct(Pedigree, fold, split)

df_plot <- df_plot %>%
  group_by(fold) %>%
  arrange(split, Pedigree, .by_group = TRUE) %>%
  mutate(idx = row_number()) %>%
  ungroup()

counts_df <- df_plot %>%
  group_by(fold, split) %>%
  summarise(count = n(), .groups = 'drop')

counts_df <- counts_df %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

ggplot(counts_df, aes(x = fold_number, y = count, fill = split)) +
  geom_bar(stat = "identity", position = "stack") +
  geom_text(aes(label = count), 
            position = position_stack(vjust = 0.5), 
            color = "white", size = 10) +
  labs(title = "DEH1.2020 Unique Genotypes per Fold",
       x = "Fold", y = "Number of Unique Genotypes") +
  scale_fill_manual(values = c(train = "#1b9e77", val = "#d95f02", test = "#7570b3")) +
  theme_minimal()+
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )


ggsave(path = "C:\\Users\\fatma\\Documents\\Lodging\\Counts_Figures", width = 9, height = 5, device='tiff', dpi=700, filename= "DEH1.2020_Genotypes_Counts_Figure.tiff")


length(unique(df$Pedigree))

#######################################
#######################################
######### Combined Envs ###############
#######################################
#######################################


############################
####### Images #############
############################

library(tidyr)
library(dplyr)
library(ggplot2)

df <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\images_and_labels_for_YOLO_training\\Combined_Envs\\splits_with_annotations.csv")

df_long <- df %>%
  pivot_longer(cols = starts_with("fold"),
               names_to = "fold",
               values_to = "split")

# Calculate group counts
counts_df <- df_long %>%
  group_by(fold, split) %>%
  summarise(count = n(), .groups = 'drop')

ggplot(counts_df, aes(x = fold, y = count, fill = split)) +
  geom_bar(stat = "identity", position = position_dodge(width=0.9)) +
  geom_text(aes(label = count), 
            position = position_dodge(width=0.9), 
            vjust = -0.25, size = 3) +
  labs(title = "Combined Envs. Image Counts within Folds", y="Count", x="Fold") +
  theme_minimal()


ggplot(counts_df, aes(x = fold, y = count, fill = split)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = count), 
            position = position_stack(vjust = 0.5), 
            size = 5, color = "black") +
  labs(title = "Combined Envs. Image Counts within Folds", y="Count", x="Fold") +
  theme_minimal()

ggsave(path = "C:\\Users\\fatma\\Documents\\Lodging\\Counts_Figures", width = 9, height = 5, device='tiff', dpi=700, filename= "Combined_Envs_Image_Counts_Figure.tiff")

length(unique(df$Name))

############################
######### Plots ############
############################

library(dplyr)
library(tidyr)
library(ggplot2)

# If not already done, pivot to long:
df_long <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split"
  ) %>%
  # Only keep train/val/test (if you have extra 'trainval' etc)
  filter(split %in% c("train", "val", "test"))

df_plot <- df_long %>%
  distinct(Plot_ID, fold, split)

df_plot <- df_plot %>%
  group_by(fold) %>%
  arrange(split, Plot_ID, .by_group = TRUE) %>%
  mutate(idx = row_number()) %>%
  ungroup()

counts_df <- df_plot %>%
  group_by(fold, split) %>%
  summarise(count = n(), .groups = 'drop')

ggplot(counts_df, aes(x = fold, y = count, fill = split)) +
  geom_bar(stat = "identity", position = "stack") +
  geom_text(aes(label = count), 
            position = position_stack(vjust = 0.5), 
            color = "white", size = 4) +
  labs(title = "Combined Envs. Unique Plots per Fold",
       x = "Fold", y = "Number of Unique Plots") +
  scale_fill_manual(values = c(train = "#1b9e77", val = "#d95f02", test = "#7570b3")) +
  theme_minimal()+
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )


ggsave(path = "C:\\Users\\fatma\\Documents\\Lodging\\Counts_Figures", width = 9, height = 5, device='tiff', dpi=700, filename= "Combined_Envs_Plots_Counts_Figure.tiff")

length(unique(df$Plot_ID))

############################
####### Genotype ###########
############################

# If not already done, pivot to long:
df_long <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split"
  ) %>%
  # Only keep train/val/test (if you have extra 'trainval' etc)
  filter(split %in% c("train", "val", "test"))

df_plot <- df_long %>%
  distinct(Pedigree, fold, split)

df_plot <- df_plot %>%
  group_by(fold) %>%
  arrange(split, Pedigree, .by_group = TRUE) %>%
  mutate(idx = row_number()) %>%
  ungroup()

counts_df <- df_plot %>%
  group_by(fold, split) %>%
  summarise(count = n(), .groups = 'drop')

counts_df <- counts_df %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

ggplot(counts_df, aes(x = fold_number, y = count, fill = split)) +
  geom_bar(stat = "identity", position = "stack") +
  geom_text(aes(label = count), 
            position = position_stack(vjust = 0.5), 
            color = "white", size = 10) +
  labs(title = "Combined Envs. Unique Genotypes per Fold",
       x = "Fold", y = "Number of Unique Genotypes") +
  scale_fill_manual(values = c(train = "#1b9e77", val = "#d95f02", test = "#7570b3")) +
  theme_minimal()+
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )


ggsave(path = "C:\\Users\\fatma\\Documents\\Lodging\\Counts_Figures", width = 9, height = 5, device='tiff', dpi=700, filename= "Combined_Envs_Genotypes_Counts_Figure.tiff")


length(unique(df$Pedigree))