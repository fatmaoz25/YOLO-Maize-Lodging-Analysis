#######################
#######################
###### DEH1.2020 ######
#######################
#######################

library(tidyr)
library(dplyr)
library(ggplot2)
library(scales) # for percent()

df <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\images_and_labels_for_YOLO_training\\DEH1.2020\\splits_with_annotations.csv")

df_long <- df %>%
  pivot_longer(cols = starts_with("fold"),
               names_to = "fold",
               values_to = "split")

df_long <- df_long %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

############

ggplot(df_long, aes(x = fold_number, fill = as.factor(Lodging))) +
  geom_bar(position = "fill") +
  facet_wrap(~split, nrow = 1) +
  theme_minimal() +
  labs(
    title = "DEH1.2020 Lodging Class Proportions in each Fold/Split",
    x = "Fold", fill = "Lodging Class", y = "Proportion"
  ) +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 20),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )
  

############

ggplot(df_long, aes(x = fold_number, fill = as.factor(Lodging))) +
  geom_bar(position = "stack") +
  facet_wrap(~split, nrow = 1) +
  labs(title = "DEH1.2020 Lodging Class Counts in each Fold/Split",
       x = "Fold", fill = "Lodging class", y = "Count") +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme_minimal() +
  theme(
    text = element_text(face = "bold", size = 20),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

###########

# Count and proportion table, in case you want to see raw numbers too
df %>%
  count(Lodging) %>%
  mutate(prop = n / sum(n))

df %>%
  count(Lodging) %>%
  mutate(prop = n / sum(n)) %>%
  ggplot(aes(x = as.factor(Lodging), y = prop, fill = as.factor(Lodging))) +
  geom_col() +
  geom_text(aes(label = scales::percent(prop, accuracy=0.1)), vjust = -0.5) +
  scale_y_continuous(labels = scales::percent_format(accuracy=1)) +
  labs(
    title = "DEH1.2020 Lodging Class Proportion Across All Data",
    x = "Lodging Class",
    y = "Proportion",
    fill = "Lodging"
  ) +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme_void() +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )+
  theme_minimal()

############

df %>%
  count(Lodging) %>%
  mutate(prop = n / sum(n)) %>%
  ggplot(aes(x = "All Data", y = prop, fill = as.factor(Lodging))) +
  geom_col(width=0.6) +
  geom_text(aes(label = percent(prop, accuracy=0.1)),
            position = position_stack(vjust = 0.5), color="black", size=20) +
  scale_y_continuous(labels = percent_format(accuracy=1)) +
  labs(
    title = "DEH1.2020 Lodging Class Proportion Across All Data",
    x = NULL,
    y = "Proportion",
    fill = "Lodging"
  ) +
  theme_minimal()+
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

##############

plot_data_split <- df_long %>%
  group_by(split, Lodging) %>%
  summarise(n = n(), .groups = "drop") %>%
  group_by(split) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()

ggplot(plot_data_split, aes(x = split, y = prop, fill = as.factor(Lodging))) +
  geom_col(position = "fill") +
  geom_text(
    aes(label = ifelse(prop >= 0.05, percent(prop, accuracy = 1), "")),
    position = position_stack(vjust = 0.5),
    color = "black", size = 15
  ) +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme_minimal()+
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )+
  labs(
    title = "DEH1.2020 Lodging Class Proportions by Split",
    x = "Split (train/val/test)",
    y = "Proportion",
    fill = "Lodging"
  ) +
  scale_y_continuous(labels = scales::percent)

#################

# 1. Summarize counts for each fold × split × Lodging
plot_data <- df_long %>%
  group_by(fold, split, Lodging) %>%
  summarise(n = n(), .groups = "drop")

plot_data <- plot_data %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

# 2. Plot: stacked bars by count with inside count labels
ggplot(plot_data, aes(x = fold_number, y = n, fill = as.factor(Lodging))) +
  geom_col() +
  geom_text(
    aes(label = n),
    position = position_stack(vjust = 0.5),
    color = "black", size = 5
  ) +
  facet_wrap(~split) +
  labs(
    title = "DEH1.2020 Lodging Class Counts by Fold and Split",
    x = "Fold",
    y = "Count",
    fill = "Lodging"
  )+
  theme_minimal()+
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

##################

plot_data_folds <- df_long %>%
  count(fold, split) %>%
  group_by(fold) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()

plot_data_folds <- plot_data_folds %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

ggplot(plot_data_folds, aes(x = fold_number, y = prop, fill = split)) +
  geom_col(position = "stack", width=0.8) +
  geom_text(aes(label = percent(prop, accuracy=0.1)), 
            position = position_stack(vjust = 0.5), color = "black", size = 10) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  labs(
    title = "DEH1.2020 Proportion of Split Assignments per Fold",
    x = "Fold",
    y = "Proportion"
  ) +
  theme_minimal()+
  scale_fill_manual(values = c("train" = "#406B8C", "test" = "#A4485E", "val" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

###########################
###########################
###########################

#######################
#######################
###### MOH2.2021 ######
#######################
#######################

library(tidyr)
library(dplyr)
library(ggplot2)
library(scales) # for percent()

df <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\images_and_labels_for_YOLO_training\\MOH2.2021\\splits_with_annotations.csv")

df_long <- df %>%
  pivot_longer(cols = starts_with("fold"),
               names_to = "fold",
               values_to = "split")

df_long <- df_long %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

############

ggplot(df_long, aes(x = fold_number, fill = as.factor(Lodging))) +
  geom_bar(position = "fill") +
  facet_wrap(~split, nrow = 1) +
  theme_minimal() +
  labs(
    title = "MOH2.2021 Lodging Class Proportions in each Fold/Split",
    x = "Fold", fill = "Lodging Class", y = "Proportion"
  ) +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 20),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )


############

ggplot(df_long, aes(x = fold_number, fill = as.factor(Lodging))) +
  geom_bar(position = "stack") +
  facet_wrap(~split, nrow = 1) +
  labs(title = "MOH2.2021 Lodging Class Counts in each Fold/Split",
       x = "Fold", fill = "Lodging class", y = "Count") +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme_minimal() +
  theme(
    text = element_text(face = "bold", size = 20),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

###########

# Count and proportion table, in case you want to see raw numbers too
df %>%
  count(Lodging) %>%
  mutate(prop = n / sum(n))

df %>%
  count(Lodging) %>%
  mutate(prop = n / sum(n)) %>%
  ggplot(aes(x = as.factor(Lodging), y = prop, fill = as.factor(Lodging))) +
  geom_col() +
  geom_text(aes(label = scales::percent(prop, accuracy=0.1)), vjust = -0.5) +
  scale_y_continuous(labels = scales::percent_format(accuracy=1)) +
  labs(
    title = "MOH2.2021 Lodging Class Proportion Across All Data",
    x = "Lodging Class",
    y = "Proportion",
    fill = "Lodging"
  ) +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme_void() +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )+
  theme_minimal()

############

df %>%
  count(Lodging) %>%
  mutate(prop = n / sum(n)) %>%
  ggplot(aes(x = "All Data", y = prop, fill = as.factor(Lodging))) +
  geom_col(width=0.6) +
  geom_text(aes(label = percent(prop, accuracy=0.1)),
            position = position_stack(vjust = 0.5), color="black", size=20) +
  scale_y_continuous(labels = percent_format(accuracy=1)) +
  labs(
    title = "MOH2.2021 Lodging Class Proportion Across All Data",
    x = NULL,
    y = "Proportion",
    fill = "Lodging"
  ) +
  theme_minimal()+
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

##############

plot_data_split <- df_long %>%
  group_by(split, Lodging) %>%
  summarise(n = n(), .groups = "drop") %>%
  group_by(split) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()

ggplot(plot_data_split, aes(x = split, y = prop, fill = as.factor(Lodging))) +
  geom_col(position = "fill") +
  geom_text(
    aes(label = ifelse(prop >= 0.05, percent(prop, accuracy = 1), "")),
    position = position_stack(vjust = 0.5),
    color = "black", size = 15
  ) +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme_minimal()+
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )+
  labs(
    title = "MOH2.2021 Lodging Class Proportions by Split",
    x = "Split (train/val/test)",
    y = "Proportion",
    fill = "Lodging"
  ) +
  scale_y_continuous(labels = scales::percent)

#################

# 1. Summarize counts for each fold × split × Lodging
plot_data <- df_long %>%
  group_by(fold, split, Lodging) %>%
  summarise(n = n(), .groups = "drop")

plot_data <- plot_data %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

# 2. Plot: stacked bars by count with inside count labels
ggplot(plot_data, aes(x = fold_number, y = n, fill = as.factor(Lodging))) +
  geom_col() +
  geom_text(
    aes(label = n),
    position = position_stack(vjust = 0.5),
    color = "black", size = 5
  ) +
  facet_wrap(~split) +
  labs(
    title = "MOH2.2021 Lodging Class Counts by Fold and Split",
    x = "Fold",
    y = "Count",
    fill = "Lodging"
  )+
  theme_minimal()+
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

##################

plot_data_folds <- df_long %>%
  count(fold, split) %>%
  group_by(fold) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()

plot_data_folds <- plot_data_folds %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

ggplot(plot_data_folds, aes(x = fold_number, y = prop, fill = split)) +
  geom_col(position = "stack", width=0.8) +
  geom_text(aes(label = percent(prop, accuracy=0.1)), 
            position = position_stack(vjust = 0.5), color = "black", size = 10) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  labs(
    title = "MOH2.2021 Proportion of Split Assignments per Fold",
    x = "Fold",
    y = "Proportion"
  ) +
  theme_minimal()+
  scale_fill_manual(values = c("train" = "#406B8C", "test" = "#A4485E", "val" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )


########################
########################
########################

#######################
#######################
###### Combined Envs ##
#######################
#######################

library(tidyr)
library(dplyr)
library(ggplot2)
library(scales) # for percent()

df <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\images_and_labels_for_YOLO_training\\Combined_Envs\\splits_with_annotations.csv")

df_long <- df %>%
  pivot_longer(cols = starts_with("fold"),
               names_to = "fold",
               values_to = "split")

df_long <- df_long %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

############

ggplot(df_long, aes(x = fold_number, fill = as.factor(Lodging))) +
  geom_bar(position = "fill") +
  facet_wrap(~split, nrow = 1) +
  theme_minimal() +
  labs(
    title = "Combined Envs. Lodging Class Proportions in each Fold/Split",
    x = "Fold", fill = "Lodging Class", y = "Proportion"
  ) +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 20),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )


############

ggplot(df_long, aes(x = fold_number, fill = as.factor(Lodging))) +
  geom_bar(position = "stack") +
  facet_wrap(~split, nrow = 1) +
  labs(title = "Combined Envs. Lodging Class Counts in each Fold/Split",
       x = "Fold", fill = "Lodging class", y = "Count") +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme_minimal() +
  theme(
    text = element_text(face = "bold", size = 20),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

###########

# Count and proportion table, in case you want to see raw numbers too
df %>%
  count(Lodging) %>%
  mutate(prop = n / sum(n))

df %>%
  count(Lodging) %>%
  mutate(prop = n / sum(n)) %>%
  ggplot(aes(x = as.factor(Lodging), y = prop, fill = as.factor(Lodging))) +
  geom_col() +
  geom_text(aes(label = scales::percent(prop, accuracy=0.1)), vjust = -0.5) +
  scale_y_continuous(labels = scales::percent_format(accuracy=1)) +
  labs(
    title = "Combined Envs. Lodging Class Proportion Across All Data",
    x = "Lodging Class",
    y = "Proportion",
    fill = "Lodging"
  ) +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme_void() +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )+
  theme_minimal()

############

df %>%
  count(Lodging) %>%
  mutate(prop = n / sum(n)) %>%
  ggplot(aes(x = "All Data", y = prop, fill = as.factor(Lodging))) +
  geom_col(width=0.6) +
  geom_text(aes(label = percent(prop, accuracy=0.1)),
            position = position_stack(vjust = 0.5), color="black", size=20) +
  scale_y_continuous(labels = percent_format(accuracy=1)) +
  labs(
    title = "Combined Envs. Lodging Class Proportion Across All Data",
    x = NULL,
    y = "Proportion",
    fill = "Lodging"
  ) +
  theme_minimal()+
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

##############

plot_data_split <- df_long %>%
  group_by(split, Lodging) %>%
  summarise(n = n(), .groups = "drop") %>%
  group_by(split) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()

ggplot(plot_data_split, aes(x = split, y = prop, fill = as.factor(Lodging))) +
  geom_col(position = "fill") +
  geom_text(
    aes(label = ifelse(prop >= 0.05, percent(prop, accuracy = 1), "")),
    position = position_stack(vjust = 0.5),
    color = "black", size = 15
  ) +
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme_minimal()+
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )+
  labs(
    title = "Combined Envs. Lodging Class Proportions by Split",
    x = "Split (train/val/test)",
    y = "Proportion",
    fill = "Lodging"
  ) +
  scale_y_continuous(labels = scales::percent)

#################

# 1. Summarize counts for each fold × split × Lodging
plot_data <- df_long %>%
  group_by(fold, split, Lodging) %>%
  summarise(n = n(), .groups = "drop")

plot_data <- plot_data %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

# 2. Plot: stacked bars by count with inside count labels
ggplot(plot_data, aes(x = fold_number, y = n, fill = as.factor(Lodging))) +
  geom_col() +
  geom_text(
    aes(label = n),
    position = position_stack(vjust = 0.5),
    color = "black", size = 5
  ) +
  facet_wrap(~split) +
  labs(
    title = "Combined Envs. Lodging Class Counts by Fold and Split",
    x = "Fold",
    y = "Count",
    fill = "Lodging"
  )+
  theme_minimal()+
  scale_fill_manual(values = c("0" = "#406B8C", "1" = "#A4485E", "2" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

##################

plot_data_folds <- df_long %>%
  count(fold, split) %>%
  group_by(fold) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup()

plot_data_folds <- plot_data_folds %>%
  mutate(fold_number = as.integer(gsub("[^0-9]", "", fold)))

ggplot(plot_data_folds, aes(x = fold_number, y = prop, fill = split)) +
  geom_col(position = "stack", width=0.8) +
  geom_text(aes(label = percent(prop, accuracy=0.1)), 
            position = position_stack(vjust = 0.5), color = "black", size = 10) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  labs(
    title = "Combined Envs. Proportion of Split Assignments per Fold",
    x = "Fold",
    y = "Proportion"
  ) +
  theme_minimal()+
  scale_fill_manual(values = c("train" = "#406B8C", "test" = "#A4485E", "val" = "#EB8445")) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )
