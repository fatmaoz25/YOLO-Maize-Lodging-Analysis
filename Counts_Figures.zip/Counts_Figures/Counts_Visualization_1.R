library(dplyr)
library(tidyr)
library(ggplot2)

# Build example data
df <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\images_and_labels_for_YOLO_training\\DEH1.2020\\splits_with_annotations.csv")

# Reshape
long_df <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split_class"
  )

# Count unique hybrids per fold, class, and tester
hybrid_counts <- long_df %>%
  group_by(fold, split_class, Tester) %>%
  summarise(unique_hybrids = n_distinct(Pedigree), .groups = "drop")

# Plot, facet by Tester
ggplot(hybrid_counts, aes(x = fold, y = unique_hybrids, fill = split_class)) +
  geom_col(position = "dodge") +
  facet_wrap(~Tester) +
  labs(
    title = "Unique Hybrids per Fold, Class and Tester",
    x = "Fold",
    y = "Number of Unique Hybrids",
    fill = "Split Class"
  ) +
  theme_minimal()

# Reshape to long format
long_df <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split_class"
  )

# Extract fold number (as a factor for plot)
hybrid_counts <- long_df %>%
  mutate(fold_num = as.factor(gsub("[^0-9]", "", fold))) %>%
  group_by(fold_num, split_class, Tester) %>%
  summarise(unique_hybrids = n_distinct(Pedigree), .groups = "drop")

# Plot, facet by Tester, horizontal, count atop bar, fold by number
ggplot(hybrid_counts, aes(x = fold_num, y = unique_hybrids, fill = split_class)) +
  geom_col(position = "dodge") +
  geom_text(aes(label = unique_hybrids),
            position = position_dodge(width = 0.9), vjust = 0.5, hjust = -0.2, size = 4) +
  facet_wrap(~Tester) +
  coord_flip() +
  labs(
    title = "Unique Hybrids per Fold, Class and Tester",
    x = "Fold Number",
    y = "Number of Unique Hybrids",
    fill = "Split Class"
  ) +
  theme_minimal()

#####################
####################
####################

# 1. Reshape
long_df <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split_class"
  )

# 2. Summarize
hybrid_table <- long_df %>%
  group_by(fold, split_class, Tester) %>%
  summarise(unique_hybrids = n_distinct(Pedigree), 
            hybrids_listed = paste(unique(Pedigree), collapse = "; "), # listing hybrids in each group
            .groups = "drop")

# 3. View as a table
print(hybrid_table)

# For pretty table in R markdown or console
knitr::kable(hybrid_table)

# For interactive table in RStudio:
DT::datatable(hybrid_table)


#####################
#####################
#####################
dff <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\human_labeled_datasets\\DEH1.2020\\final.DEH1.2020.Lodging.csv")

print(length(unique(dff$Pedigree)))
print(length(unique(dff$Plot_ID)))


library(dplyr)

# 1. Count unique plot IDs per pedigree
pedigree_plotid_counts <- dff %>%
  group_by(Pedigree) %>%
  summarise(
    unique_plot_count = n_distinct(Plot_ID)
  )

# 2. Filter those with more than one unique plot
pedigree_multi_plot <- pedigree_plotid_counts %>%
  filter(unique_plot_count > 1)

# 3. How many pedigrees have more than one plot?
num_pedigrees_multiple_plots <- nrow(pedigree_multi_plot)

# 4. Show the pedigrees and their counts
print(pedigree_multi_plot)
print(paste("Number of unique pedigrees with multiple unique plot IDs:", num_pedigrees_multiple_plots))

###################
###################
###################

library(ggplot2)
library(dplyr)

# Pie chart data: Tester frequency across all rows
tester_obs_counts <- df %>% 
  count(Tester)

# Plot
ggplot(tester_obs_counts, aes(x = "", y = n, fill = Tester)) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  labs(title = "Tester Split (All Observations)", y = "Count", x = NULL) +
  theme_void() +
  geom_text(aes(label = n), position = position_stack(vjust = 0.5))


# Pie chart data: Tester frequency across unique Pedigrees
# Each pedigree is counted only once, even if it appears multiple times
tester_pedigree_counts <- df %>% 
  distinct(Pedigree, Tester) %>%   # Get unique combinations
  count(Tester)

total <- sum(tester_pedigree_counts$n)

# Plot
ggplot(tester_pedigree_counts, aes(x = "", y = n, fill = Tester)) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  labs(title = "DEH1.2020 Tester Split Across all Hybrids", y = "Count", x = NULL, subtitle = paste("Total Hybrids:", total)) +
  scale_fill_manual(values = c("PHK76" = "#6c5070", "PHZ51" = "#df6a6a", "PHP02" = "#c2dbc1")) +
  theme_void() +
  geom_text(aes(label = n), fontface="bold", position = position_stack(vjust = 0.5), size = 30) +
  theme(text = element_text(face = "bold", size = 30), (plot.subtitle = element_text(face = "bold", size = 30)))

#######################
#######################
#######################

library(dplyr)

# Calculate counts per Tester and Lodging class
tester_lodging_counts <- df %>%
  group_by(Tester, Lodging) %>%
  summarise(count = n(), .groups = "drop")

total_images <- nrow(df)

library(ggplot2)

ggplot(tester_lodging_counts, aes(x = "", y = count, fill = factor(Lodging))) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  facet_wrap(~Tester) +
  labs(
    title = "DEH1.2020 Lodging Scores within Each Tester",
    subtitle = paste("Total Images:", total_images),
    fill = "Lodging Score",
    y = "Count",
    x = NULL
  ) +
  scale_fill_manual(values = c("0" = "#DB3E8C", "1" = "#66A5ED", "2" = "#F6C45C")) +
  theme_void() +
  geom_text(
    aes(label = count),
    position = position_stack(vjust = 0.5),
    fontface = "bold",
    size = 12
  ) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

###################################################
###################################################
###################################################


library(dplyr)
library(tidyr)
library(ggplot2)

# Build example data
df <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\images_and_labels_for_YOLO_training\\MOH2.2021\\splits_with_annotations.csv")

# Reshape
long_df <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split_class"
  )

# Count unique hybrids per fold, class, and tester
hybrid_counts <- long_df %>%
  group_by(fold, split_class, Tester) %>%
  summarise(unique_hybrids = n_distinct(Pedigree), .groups = "drop")

# Plot, facet by Tester
ggplot(hybrid_counts, aes(x = fold, y = unique_hybrids, fill = split_class)) +
  geom_col(position = "dodge") +
  facet_wrap(~Tester) +
  labs(
    title = "Unique Hybrids per Fold, Class and Tester",
    x = "Fold",
    y = "Number of Unique Hybrids",
    fill = "Split Class"
  ) +
  theme_minimal()

# Reshape to long format
long_df <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split_class"
  )

# Extract fold number (as a factor for plot)
hybrid_counts <- long_df %>%
  mutate(fold_num = as.factor(gsub("[^0-9]", "", fold))) %>%
  group_by(fold_num, split_class, Tester) %>%
  summarise(unique_hybrids = n_distinct(Pedigree), .groups = "drop")

# Plot, facet by Tester, horizontal, count atop bar, fold by number
ggplot(hybrid_counts, aes(x = fold_num, y = unique_hybrids, fill = split_class)) +
  geom_col(position = "dodge") +
  geom_text(aes(label = unique_hybrids),
            position = position_dodge(width = 0.9), vjust = 0.5, hjust = -0.2, size = 4) +
  facet_wrap(~Tester) +
  coord_flip() +
  labs(
    title = "Unique Hybrids per Fold, Class and Tester",
    x = "Fold Number",
    y = "Number of Unique Hybrids",
    fill = "Split Class"
  ) +
  theme_minimal()

#####################
####################
####################

# 1. Reshape
long_df <- df %>%
  pivot_longer(
    cols = starts_with("fold"),
    names_to = "fold",
    values_to = "split_class"
  )

# 2. Summarize
hybrid_table <- long_df %>%
  group_by(fold, split_class, Tester) %>%
  summarise(unique_hybrids = n_distinct(Pedigree), 
            hybrids_listed = paste(unique(Pedigree), collapse = "; "), # listing hybrids in each group
            .groups = "drop")

# 3. View as a table
print(hybrid_table)

# For pretty table in R markdown or console
knitr::kable(hybrid_table)

# For interactive table in RStudio:
DT::datatable(hybrid_table)


#####################
#####################
#####################
dff <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\human_labeled_datasets\\MOH2.2021\\final.MOH2.2021.Lodging.csv")

print(length(unique(dff$Pedigree)))
print(length(unique(dff$Plot_ID)))


library(dplyr)

# 1. Count unique plot IDs per pedigree
pedigree_plotid_counts <- dff %>%
  group_by(Pedigree) %>%
  summarise(
    unique_plot_count = n_distinct(Plot_ID)
  )

# 2. Filter those with more than one unique plot
pedigree_multi_plot <- pedigree_plotid_counts %>%
  filter(unique_plot_count > 1)

# 3. How many pedigrees have more than one plot?
num_pedigrees_multiple_plots <- nrow(pedigree_multi_plot)

# 4. Show the pedigrees and their counts
print(pedigree_multi_plot)
print(paste("Number of unique pedigrees with multiple unique plot IDs:", num_pedigrees_multiple_plots))

###################
###################
###################

library(ggplot2)
library(dplyr)

# Pie chart data: Tester frequency across all rows
tester_obs_counts <- df %>% 
  count(Tester)

# Plot
ggplot(tester_obs_counts, aes(x = "", y = n, fill = Tester)) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  labs(title = "Tester Split (All Observations)", y = "Count", x = NULL) +
  theme_void() +
  geom_text(aes(label = n), position = position_stack(vjust = 0.5))


# Pie chart data: Tester frequency across unique Pedigrees
# Each pedigree is counted only once, even if it appears multiple times
tester_pedigree_counts <- df %>% 
  distinct(Pedigree, Tester) %>%   # Get unique combinations
  count(Tester)

total <- sum(tester_pedigree_counts$n)

# Plot
ggplot(tester_pedigree_counts, aes(x = "", y = n, fill = Tester)) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  labs(title = "MOH2.2021 Tester Split Across all Hybrids", y = "Count", x = NULL, subtitle = paste("Total Hybrids:", total)) +
  scale_fill_manual(values = c("PHK76" = "#6c5070", "PHZ51" = "#df6a6a", "PHP02" = "#c2dbc1")) +
  theme_void() +
  geom_text(aes(label = n), fontface="bold", position = position_stack(vjust = 0.5), size = 30) +
  theme(text = element_text(face = "bold", size = 30), (plot.subtitle = element_text(face = "bold", size = 30)))

#######################
#######################
#######################

library(dplyr)

# Calculate counts per Tester and Lodging class
tester_lodging_counts <- df %>%
  group_by(Tester, Lodging) %>%
  summarise(count = n(), .groups = "drop")

total_images <- nrow(df)

library(ggplot2)

ggplot(tester_lodging_counts, aes(x = "", y = count, fill = factor(Lodging))) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  facet_wrap(~Tester) +
  labs(
    title = "MOH2.2021 Lodging Scores within Each Tester",
    subtitle = paste("Total Images:", total_images),
    fill = "Lodging Score",
    y = "Count",
    x = NULL
  ) +
  scale_fill_manual(values = c("0" = "#DB3E8C", "1" = "#66A5ED", "2" = "#F6C45C")) +
  theme_void() +
  geom_text(
    aes(label = count),
    position = position_stack(vjust = 0.5),
    fontface = "bold",
    size = 12
  ) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30),
    strip.text = element_text(face = "bold", size = 30, margin = margin(t = 30, b = 0))
  )

###########

phz51_counts <- tester_lodging_counts %>% filter(Tester == "PHZ51")

ggplot(phz51_counts, aes(x = "", y = count, fill = factor(Lodging))) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  labs(
    title = "MOH2.2021 Lodging Scores for PHZ51 Tester",
    subtitle = paste("Total Images:", sum(phz51_counts$count)),
    fill = "Lodging Score",
    y = "Count",
    x = NULL
  ) +
  scale_fill_manual(values = c("0" = "#DB3E8C", "1" = "#66A5ED", "2" = "#F6C45C")) +
  theme_void() +
  geom_text(
    aes(label = count),
    position = position_stack(vjust = 0.5),
    fontface = "bold",
    size = 12
  ) +
  theme(
    text = element_text(face = "bold", size = 30),
    plot.subtitle = element_text(face = "bold", size = 30)
  )