####################
##### MOH2.2021 ###
###################

library(dplyr)

df <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\human_labeled_datasets\\MOH2.2021\\Cleaned.MOH2.2021.Lodging.csv")
df <- df %>% 
  filter(Tester %in% c("PHZ51", "PHK76", "PHP02"))

write.csv(df, "C:\\Users\\fatma\\Documents\\Lodging\\human_labeled_datasets\\MOH2.2021\\Filtered.MOH2.2021.Lodging.csv")

####################
##### DEH1.2020 ###
###################

library(dplyr)

df <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\human_labeled_datasets\\DEH1.2020\\Cleaned.DEH1.2020.Lodging.csv")
df <- df %>% 
  filter(Tester %in% c("PHZ51", "PHK76", "PHP02"))

write.csv(df, "C:\\Users\\fatma\\Documents\\Lodging\\human_labeled_datasets\\DEH1.2020\\Filtered.DEH1.2020.Lodging.csv")
