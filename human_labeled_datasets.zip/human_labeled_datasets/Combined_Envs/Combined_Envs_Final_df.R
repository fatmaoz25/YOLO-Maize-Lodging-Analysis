df1 <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\human_labeled_datasets\\DEH1.2020\\final.DEH1.2020.Lodging.csv")
  
df2 <- read.csv("C:\\Users\\fatma\\Documents\\Lodging\\human_labeled_datasets\\MOH2.2021\\final.MOH2.2021.Lodging.csv")

df1 <- df1 %>% select(-Grain.Yield..bu.A.)

df_combined <- rbind(df1, df2)
# or, safer for column names:
df_combined <- dplyr::bind_rows(df1, df2)

write.csv(df_combined, "C:\\Users\\fatma\\Documents\\Lodging\\human_labeled_datasets\\Combined_Envs\\final.Combined.Envs.Lodging.csv")
