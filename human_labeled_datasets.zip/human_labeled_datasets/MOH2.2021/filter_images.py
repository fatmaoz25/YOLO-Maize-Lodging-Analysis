import os
import shutil
import pandas as pd

# 1. Read your DataFrame
df = pd.read_csv(r'C:\Users\fatma\Documents\Lodging\human_labeled_datasets\MOH2.2021\Filtered.MOH2.2021.Lodging.csv')  # Uncomment if loading from CSV

# 2. Set your folder paths
source_folder = r'C:\Users\fatma\Documents\Lodging\images_and_labels_for_YOLO_training\MOH2.2021\images'
filtered_folder = r'C:\Users\fatma\Documents\Lodging\images_and_labels_for_YOLO_training\MOH2.2021\filtered_folder'

# 3. Create destination folder if it doesn't exist
os.makedirs(filtered_folder, exist_ok=True)

# 4. Get list of target names from DataFrame (assuming no extension in Name column)
names = set(df['Name'].astype(str).tolist())

# 5. Loop through source_folder and copy images matching Name
for filename in os.listdir(source_folder):
    # Remove extension from files to match the Name column
    name_no_ext, ext = os.path.splitext(filename)
    if name_no_ext in names:
        shutil.copy2(
            os.path.join(source_folder, filename),
            os.path.join(filtered_folder, filename)
        )

print(f"Copied {len(os.listdir(filtered_folder))} files to {filtered_folder}")

##############
##############
##############

import os
import pandas as pd

# 1. Count unique Plot_ID values in CSV/DataFrame
# Assuming df is already read:
num_unique_plot_id = df['Plot_ID'].nunique()
print(f"Unique Plot_ID values in CSV: {num_unique_plot_id}")

# 2. Extract values after underscore in filenames, count unique
filtered_folder = r'C:\Users\fatma\Documents\Lodging\images_and_labels_for_YOLO_training\MOH2.2021\filtered_folder'

# Get all filenames (without extension)
filenames = [os.path.splitext(f)[0] for f in os.listdir(filtered_folder) if not f.startswith('.')]

# Extract part after underscore
second_parts = [name.split('_')[1] for name in filenames if '_' in name]

num_unique_second_parts = len(set(second_parts))
print(f"Unique values after underscore in image names: {num_unique_second_parts}")

###############
###############
###############

# Remove extensions to get base names
filenames_no_ext = [os.path.splitext(f)[0] for f in filenames]
# Filter DataFrame to only rows where Name matches image base name
filtered_df = df[df['Name'].astype(str).isin(filenames_no_ext)]
print(filtered_df)
filtered_df.to_csv(r'C:\Users\fatma\Documents\Lodging\human_labeled_datasets\MOH2.2021\final.MOH2.2021.Lodging.csv', index=False)

num_unique_names = filtered_df['Name'].nunique()
print(f"Unique Name values in CSV: {num_unique_names}")